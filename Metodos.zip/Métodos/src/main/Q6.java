package main;

public class Q6 {
    
    public static int conta_vogal(String str){
        
        int n = 0;
        
        for(char c : str.toCharArray()) if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') n++;
        
        return n;
        
    }
    
}
