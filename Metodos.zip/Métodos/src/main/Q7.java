package main;

public class Q7 {
    
    public static boolean[] verifica_senha(String senha){
        
        boolean[] verifs = new boolean[4];
        
        verifs[1] = true;
        
        // Se a senha tem pelo menos 10 caracteres
        verifs[0] = senha.length() >= 10;
        
        // Número de digitos
        int ndigits = 0;
        
        for(char c : senha.toCharArray()){
            
            if(Character.isDigit(c)) ndigits ++;
            else if(Character.isAlphabetic(c)) {
                
                // Se qualquer caractere for letra maiúscula
                if(Character.isUpperCase(c)) verifs[3] |= true;
                
            } else {
                verifs[1] &= false;
            }
            
        }
        
        // Se ao menos houverem dois dígitos
        verifs[2] = ndigits >= 2;
        
        return verifs;
        
    }
    
}
