package main;

import java.util.Arrays;

public class Main {

/*; Questões respondidas:
    
    4. Escreva um programa contendo métodos que operam sobre vetores de inteiros. Para cada
    método, escreva um código (chamada) que teste a sua funcionalidade.
        (a) Troca o primeiro elemento com o último elemento do vetor.
        (b) Mova todos os elementos uma posição a frente e o último elemento se torne o primeiro. Por exemplo, 1, 4, 9, 16, 25 seria transformado em 25, 1, 4, 9, 16.
        (c) Substitua todos os elementos com valores pares por zero.
        (d) Substitua todos os elementos em posições pares do vetor por zero.
        (e) Retorne true se o vetor estiver ordenado em ordem crescente.
        (f)Retorne true se o vetor conter elementos duplicados. Por exemplo, 1, 1, 2, 3 retorna true, mas 1, 2, 3, 4 retorna false.
    
5. Escreva um método:
    1 public static boolean iguais ( int [] a , int [] b) ...
que verifica se os dois vetores têm os mesmos elementos na mesma ordem.
    
6. Escreva um método Java que retorne a quantidade de vogais em uma String passada como
parâmetro.
    
7. Escreva um método Java para verificar se uma String representa uma senha válida seguindo as seguintes regras:
    • Uma senha deve ter pelo menos dez caracteres.
    • Uma senha consiste apenas em letras e dígitos.
    • Uma senha deve conter pelo menos dois dígitos
    • Uma senha deve ter pelo menos uma letra maiúscula.
    
8. Escreva um método Java que aceite três inteiros como parâmetro e verifique se eles são
consecutivos ou não. Retorne verdadeiro ou falso. Por exemplo, 14, 15, 16 são consecutivos; 14,17,20 não são consecutivos; e 14, 10, 5 não são consecutivos.
Página 2 / 3
    
9. Escreva os métodos a seguir e forneça um programa para testá-los.
    • boolean todosIguais(double x, double y, double z), retornando true se os
argumentos são todos iguais.
    • boolean todosDiferentes(double x, double y, double z), retornando true se
os argumentos são todos diferentes.
    • boolean ordenados(double x, double y, double z), retornando true se os argumentos forem ordenados, com o menor vindo primeiro.

10. Escreva um método String repete(String str, int n), que retorna a String str repetida n vezes. Por exemplo, repete("Oi",3) retorna "OiOiOi".

11. Escreva um método String repete(String str, String escape, int n), que retorna
a String str repetida n vezes, separada por escape. Por exemplo, repete("Oi","_", 4)
retorna "Oi_Oi_Oi_Oi".
    
12. Escreva um método:
    1 public static int soma ( int [][] matriz ) ...
    que retorna a soma de todos os elementos dentro de “matriz”.

*/
    public static void main(String[] args) {
        
        int[] vetor = {1,2,3,4,5,5};
        
        System.out.println( "Vetor: " + Arrays.toString(vetor) );
        
        System.out.println("Q4.");
        System.out.println( "\ta) " + Arrays.toString( Q4.troca_primeiro_por_ultimo(vetor) ) );
        System.out.println( "\tb) " + Arrays.toString( Q4.mover_pra_frente(vetor) ) );
        System.out.println( "\tc) " + Arrays.toString( Q4.substituir_pares_por_zero(vetor) ) );
        System.out.println( "\td) " + Arrays.toString( Q4.substituir_posicoes_pares_por_zero(vetor) ) );
        System.out.println( "\te) " + Q4.ordem_crescente(vetor) );
        System.out.println( "\tf) " + Q4.tem_duplicado(vetor) );
        
        System.out.println("Q5.");
        int[] a = {1,2,3}, b = {1,2,1};
        System.out.println( "\t" + Q5.iguais(a, b) );
        
        System.out.println("Q6.");
        String string = "Bom Dia Professor Pena";
        System.out.println( "\t" + "Quantidade de vogais na string: " + Q6.conta_vogal(string) );
        
        System.out.println("Q7.");
        String senha = "SussyBaka123.";
        boolean[] verificacao = Q7.verifica_senha(senha);
        System.out.println("\tTem o minimo de caracteres? " + verificacao[0]);
        System.out.println("\tPossui apenas caracteres alfanumericos? " + verificacao[1]);
        System.out.println("\tContem ao menos dois digitos? " + verificacao[2]);
        System.out.println("\tTem ao menos uma letra maiuscula? " + verificacao[3]);
        if(verificacao[0]&&verificacao[1]&&verificacao[2]&&verificacao[3]) System.out.println("\tSenha Valida! :D");
        else System.out.println("\tEssa senha e invalida!");
        
        int a8 = 1, b8 = 2, c8 = 3;
        
        System.out.println("Q8.");
        System.out.println("\tResposta: " + Q8.consecutivos(a8, b8, c8));
        
        int a9 = 10, b9 = 10, c9 = 10;
        
        System.out.println("Q9.");
        System.out.println( "\ta) " + Q9.todosIguais(a9, b9, c9) );
        System.out.println( "\tb) " + Q9.todosDiferentes(a9, b9, c9) );
        System.out.println( "\tc) " + Q9.ordenados(a9, b9, c9) );
        
        String str = "Oi"; int n = 3;
        System.out.println("Q10.");
        System.out.println("\t\"" + str + "\" * " + n + " = " + Q10.repete(str, n));
        
        String str11 = "Oi", escape = "+"; int n11 = 3;
        System.out.println("Q11.");
        System.out.println("\tResposta: " + Q11.repete(str11, escape, n11));
        
        int[][] matriz = {
            {1,2},
            {3,4},
            {5,6}
        };
        
        System.out.println("Q12");
        System.out.println("\tMatriz: " + Arrays.deepToString(matriz));
        System.out.println("\tSoma dos valores = " + Q12.soma(matriz));
        
    }
    
}
