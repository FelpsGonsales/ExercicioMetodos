package main;

public class Q8 {
    
    public static boolean consecutivos(int a, int b, int c){
        
        return (c - b == 1) && (b - a == 1);
        
    }
    
}
