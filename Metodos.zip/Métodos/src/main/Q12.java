package main;

public class Q12 {
    
    public static int soma(int[][] matriz){
        
        int sum = 0;
        
        for(int[] vetor : matriz) for(int n : vetor) sum += n;
        
        return sum;
        
    }
    
}
