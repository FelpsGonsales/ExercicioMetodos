package main;

public class Q9 {
    
    public static boolean todosIguais(double a, double b, double c){
        
        return (a==b)&&(a==c)&&(b==c);
        
    }
    
    public static boolean todosDiferentes(double a, double b, double c){
        
        return (a!=b)&&(a!=c)&&(b!=c);
        
    }
    
    public static boolean ordenados(double a, double b, double c){
        
        return (a<=b)&&(b<=c);
        
    }
    
}
