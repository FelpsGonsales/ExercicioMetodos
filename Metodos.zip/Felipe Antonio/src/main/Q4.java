package main;

public class Q4 {
    
    /* Alternativa a) */
    public static int[] troca_primeiro_por_ultimo(int[] vetor){
        
        int[] clone = vetor.clone();
        
        int primeiro = clone[0];
        
        clone[0] = vetor[vetor.length - 1];
        clone[vetor.length - 1] = primeiro;
        
        return clone;
        
    }
    
    /* Alternativa b) */
    public static int[] mover_pra_frente(int[] vetor){
        
        int[] aux = new int[ vetor.length ];
        
        for(int i = 0; i < aux.length; i++){
            
            aux[(i+1)%aux.length] = vetor[i];
            
        }
        
        return aux;
        
    }
    
    /* Alternativa c) */
    public static int[] substituir_pares_por_zero(int[] vetor){
        
        int[] clone = vetor.clone();
        
        for(int i = 0; i < vetor.length; i++){
            
            if(vetor[i] % 2 == 0){
                clone[i] = 0;
            }
            
        }
        
        return clone;
        
    }
    
    /* Alternativa d) */
    public static int[] substituir_posicoes_pares_por_zero(int[] vetor){
        
        int[] clone = vetor.clone();
        
        for(int i = 0; i < vetor.length; i++){
            
            if(i % 2 == 0){
                clone[i] = 0;
            }
            
        }
        
        return clone;
        
    }
    
    /* Alternativa e) */
    public static boolean ordem_crescente(int[] vetor){
        
        int x = vetor[0];
        
        for(int i = 1; i < vetor.length; i++){
            
            if(x > vetor[i]){
                return false;
            }
            
            x = vetor[i];
            
        }
        
        return true;
        
    }
    
    /* Alternativa f) */
    public static boolean tem_duplicado(int[] vetor){
        
        int len = vetor.length;
        
        for(int i = 0; i < len; i++) for(int j = 0; j < len; j++){
            
            if((i != j) && (vetor[i] == vetor[j])){
                return true;
            }
            
        }
        
        return false;
        
    }
    
}
