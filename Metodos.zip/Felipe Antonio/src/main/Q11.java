package main;

import java.util.Arrays;

public class Q11 {
    
    public static String repete(String str, String escape, int n){
        
        String[] strs = new String[n];
        
        Arrays.fill(strs, str);
        
        return String.join(escape, strs);
        
    }
    
}
