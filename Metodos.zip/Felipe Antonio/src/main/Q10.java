package main;

public class Q10 {
    
    public static String repete(String str, int n){
        
        // Poderia ser brevemente feito assim: str.repeat(n);
        
        String base = "";
        
        for(int i = 0; i < n; i++) base += str;
        
        return base;
        
    }
    
}
